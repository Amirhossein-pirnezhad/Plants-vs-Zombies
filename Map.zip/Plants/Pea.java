package Plants;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;
import static Map.Sizes.*;

public class Pea {
    private Image peaImage;
    private ImageView peaView;
    private double speed;
    private Timeline shot;
    private Plant plant;

    public Pea(Plant plant){
        peaImage = new Image(getClass().getResourceAsStream("/Bullets/PeaNormal/PeaNormal_0.png"));
        peaView = new ImageView(peaImage);
        this.plant = plant;
        animPea();
    }

    public void animPea(){
        peaView.setX(plant.col * CELL_SIZE + START_X_GRID);
        peaView.setY((plant.row + 1)* CELL_SIZE);
        shot = new Timeline(new KeyFrame(Duration.millis(100) , event -> {
            peaView.setX(peaView.getX() + 10);
        }));
        shot.setCycleCount(Animation.INDEFINITE);
        shot.play();
    }

    public ImageView getPeaView() {
        return peaView;
    }
}
