package Plants;

public class Repeater extends Peashooter{
    public Repeater(int row, int col) {
        super(row, col);
        setImage("/Plants/RepeaterPea/RepeaterPea_" , 15);
        peaInCircle = 2;
    }
}
