package Plants;

public class TallNut extends WallNut{
    public TallNut(int row, int col) {
        super(row, col);
        HP = 30;
    }
}
