package Map;

import javafx.scene.layout.StackPane;

public class Shovel extends StackPane {
    public Shovel(){
        this.setOnMouseClicked(event -> {

        });
    }
}
