package Map;

public enum CardsType {
    PEASHOOTRER , REPEATER , SNOWPEA , SUNFLOWER , WALLNUT,
    TALLNUT , CHERRYBOMB , JALAPENO
}
