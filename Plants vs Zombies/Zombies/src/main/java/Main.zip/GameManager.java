import Map.Map;
import Plants.Plant;
import Zombies.Zombie;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;

public class GameManager {
    private Map map;
    private Pane gamePane;
    private List<Zombie> zombies = new ArrayList<>();
    private List<Plant> plants = new ArrayList<>();
    private int sun = 0;

    public GameManager(Map map, Pane gamePane) {
        this.map = map;
        this.gamePane = gamePane;
    }

    public void addZombie(Zombie z) {
        zombies.add(z);
        gamePane.getChildren().add(z.getZombieView());
        z.run();
    }

    public void addPlant(Plant p, int row, int col) {
        plants.add(p);
        map.getCells()[row][col].setCellView(p.getPlantView());
        map.getCells()[row][col].getChildren().add(p.getPlantView());
    }

    public void updateGame() {

    }

    public void spawnZombie(){
        Timeline spawnZombies = new Timeline(new KeyFrame(Duration.seconds(5), e -> {
            int col = (int)(Math.random() * 100) % 5;
            Zombie z = new Zombie(1, 2, col);
            addZombie(z);
        }));
        spawnZombies.setCycleCount(Timeline.INDEFINITE);
        spawnZombies.play();
    }
}
